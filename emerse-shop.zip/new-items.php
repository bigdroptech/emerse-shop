<div class="row">
	<div class="owl-carousel">

		<div class="text-center">
			<div class="product-target text-center">
				<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
				<div class="discount-tag">20% <span>off</span></div>
				<p class="pr-name">Product Name</p>
				<p class="pr-price">KES 800</p>
				<p><a href="product.php" class="i-want-this">I want this</a></p>

				<!-- <div class="portfolio_images_overlay text-center">
					<a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
				</div> -->
			</div>
		</div>

		<div class="text-center">
			<div class="product-target text-center">
				<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
				<div class="discount-tag">20% <span>off</span></div>
				<p class="pr-name">Product Name</p>
				<p class="pr-price">KES 800</p>
				<p><a href="product.php" class="i-want-this">I want this</a></p>

				<!-- <div class="portfolio_images_overlay text-center">
					<a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
				</div> -->
			</div>
		</div>

		<div class="text-center">
			<div class="product-target text-center">
				<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
				<div class="discount-tag">20% <span>off</span></div>
				<p class="pr-name">Product Name</p>
				<p class="pr-price">KES 800</p>
				<p><a href="product.php" class="i-want-this">I want this</a></p>

				<!-- <div class="portfolio_images_overlay text-center">
					<a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
				</div> -->
			</div>
		</div>

		<div class="text-center">
			<div class="product-target text-center">
				<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
				<div class="discount-tag">20% <span>off</span></div>
				<p class="pr-name">Product Name</p>
				<p class="pr-price">KES 800</p>
				<p><a href="product.php" class="i-want-this">I want this</a></p>

				<!-- <div class="portfolio_images_overlay text-center">
					<a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
				</div> -->
			</div>
		</div>

		<div class="text-center">
			<div class="product-target text-center">
				<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
				<div class="discount-tag">20% <span>off</span></div>
				<p class="pr-name">Product Name</p>
				<p class="pr-price">KES 800</p>
				<p><a href="product.php" class="i-want-this">I want this</a></p>

				<!-- <div class="portfolio_images_overlay text-center">
					<a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
				</div> -->
			</div>
		</div>

		<div class="text-center">
			<div class="product-target text-center">
				<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
				<div class="discount-tag">20% <span>off</span></div>
				<p class="pr-name">Product Name</p>
				<p class="pr-price">KES 800</p>
				<p><a href="product.php" class="i-want-this">I want this</a></p>

				<!-- <div class="portfolio_images_overlay text-center">
					<a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
				</div> -->
			</div>
		</div>

	</div>
</div>