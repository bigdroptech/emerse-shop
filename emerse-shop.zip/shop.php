<?php
    include "header.php";
 ?>



	<div class="primary-div">
		
		<div class="col-md-4 col-sm-4 hidden-xs">
			<div class="row">

				<div class="col-md-12 shop-sidebar">
					<div class="side-header">
						Mens' Subcategories
					</div>
					<div class="side-content">
						<ul>
							<a href=""><li>T-Shirts</li></a>
							<a href=""><li>Bombers</li></a>
						</ul>
					</div>
				</div>

			</div>
		</div>

		<div class="shop-shelf col-md-8 col-sm-8 col-xs-12">
			<div class="row">

				<div class="shop-banner">
					<img src="assets/img/banner.gif" alt="">
				</div>
				
				<!-- Shop Products -->
				<div class="shop-products">

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>	

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>	

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
						<!-- 	<div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>


					<!-- Offer Section -->
					<div class="col-md-12 col-sm-12 col-xs-12 shop-offer">
						<h4 class="text-center custom-message">check out <span>new </span>Items</h4>

							<!-- Item slider-->
						<div class="container-fluid">
							
							<?php
							include "new-items.php";
							?>

						</div>
						<!-- Item slider end-->
					</div>
					<!-- /Offer Section -->

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>	

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>

					<div class="product text-center">
						<div class="product-target text-center">
							<a href="product.php"><img src="assets/img/connedverse.jpg" alt=""></a>
							<!-- <div class="discount-tag">20% <span>off</span></div> -->
							<p class="pr-name">Product Name</p>
							<p class="pr-price">KES 800</p>
							<p><a data-toggle="modal" href="#cba" class="i-want-this">I want this</a></p>

							<!-- <div class="portfolio_images_overlay text-center hidden-xs">
							                                <a href="#" class="add-to-cart"><i class="material-icons">shopping_cart</i></a>
							                            </div> -->
						</div>
					</div>
				




				</div>
				<!-- Shop Products End-->
			
			</div>
		</div>

	</div>


<?php
    include "footer.php";
 ?>